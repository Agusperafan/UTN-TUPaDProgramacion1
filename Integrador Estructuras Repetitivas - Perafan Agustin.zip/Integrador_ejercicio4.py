energia = 100
tiempo = 12
cerraduras_abiertas = 0
alarma = False
codigo_parcial = ''

nombre_agente = input('Ingrese su nombre de agente: ')
while not nombre_agente.isalpha():
    print('Ingrese un nombre válido.')
    nombre_agente = input('Ingrese su nombre de agente: ')

contador_forzar = 0

while (energia > 0) and (tiempo >0) and (cerraduras_abiertas < 3) and (alarma == False or tiempo > 3 or cerraduras_abiertas >= 3):
    print('1)Forzar cerradura     2)Hackear panel     3)Descansar')
    opcion = input('Ingrese una opción: ')
    while not opcion.isdigit():
        print('Ingrese un número válido.')
        opcion = input('Opción: ')
    opcion = int(opcion)
    if opcion == 1:
        contador_forzar += 1
        energia -= 20
        tiempo -= 2
        if energia <= 20:
            print('Te quedaste sin energia, has perdido el juego.')
        elif energia <= 40:
            print('Hay riesgo de alarma! Elegí un número (1-3) y seguro te salvas.')
            opcion_alarma = input('Ingrese su número:')
            while not opcion_alarma.isdigit() or (int(opcion_alarma) != 1) and (int(opcion_alarma) != 2) and (int(opcion_alarma) != 3):
                print('Ingrese un número válido.')
                opcion_alarma = input('Ingrese su número: ')
            opcion_alarma = int(opcion_alarma)
            if opcion_alarma == 3:
                print('Se activó la alarma!')
                alarma = True
        if tiempo <= 2:
            print('Te quedaste sin tiempo, has perdido el juego.')
        if alarma == False and contador_forzar < 3:
            cerraduras_abiertas += 1
            print('1 Cerradura abierta!')
        if contador_forzar >= 3:
            alarma = True
            print('Se activó la alarma!')
        print(f'Tu energía actual es {energia} y tu tiempo restante es {tiempo}')
    elif opcion == 2:
        contador_forzar = 0
        if energia <= 10:
            print('Te quedaste sin energía, has perdido el juego.')
        else:
            energia -= 10
        if tiempo <=3:
            print('Te quedaste sin tiempo, has perdido el juego.')
        else:
            tiempo -= 3
        for i in range(4):
            print('Se agrega la letra "A" al código.')
            codigo_parcial += 'A'
            print(f'El codigo parcial es: {codigo_parcial}')
        if (len(codigo_parcial) >= 8) and (cerraduras_abiertas < 3):
            cerraduras_abiertas += 1
            print('1 Cerradura abierta!')
        print(f'Tu energía actual es de {energia} y tu tiempo restante es {tiempo}')
    elif opcion == 3:
        contador_forzar = 0
        energia += 15
        if energia > 100:
            energia = 100
        tiempo -= 1
        print(f'Tu tiempo restante es {tiempo}')
        if alarma == True:
            energia -= 10
        print(f'Recuperaste energía, tu energía ahora es de {energia}')
    else:
        print('Elegí una opcion válida (1-3).')

if cerraduras_abiertas == 3:
    print('Ganaste! Lograste abrir todas las cerraduras!!')

if (alarma == True and tiempo <= 3 or cerraduras_abiertas < 3):
    print('Se activó la alarma y no lograste salir a tiempo, has perdido el juego.')