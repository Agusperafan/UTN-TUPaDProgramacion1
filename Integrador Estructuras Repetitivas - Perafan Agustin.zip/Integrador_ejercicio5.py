vida_gladiador = 100
vida_enemigo = 100
pociones = 3
ataque_pesado = 15
ataque_enemigo = 12
turno_gladiador = True

print('<====|- BIENVENIDOS A LA ARENA -|====>') #supuestamente eso simula una espada
nombre_gladiador = input('Ingrese el nombre del gladiador: ')
while not nombre_gladiador.isalpha():
    print('Error: Solo se permiten letras.')
    nombre_gladiador = input('Ingrese el nombre del gladiador: ')


while (vida_enemigo > 0) and (vida_gladiador > 0):
    if (vida_enemigo == 100) and (vida_gladiador == 100):
        print('---- INICIO DEL COMBATE ----')
    elif turno_gladiador:
        print()
        print('---- NUEVO TURNO ----')
    if turno_gladiador:
        print(f'{nombre_gladiador} HP:{vida_gladiador} vs Enemigo HP:{vida_enemigo}  | Pociones: {pociones}')
        print('''
    Elije una opción:
    1. Atque Pesado
    2. Ráfaga Veloz
    3. Curar
    ''')
        opcion = input('Opción: ')
        while not opcion.isdigit() or (int(opcion) !=1 and int(opcion) !=2 and int(opcion) !=3):
            if opcion.isdigit():
                print('Ingrese un número valido (1, 2 o 3).')
            else: 
                print('Solo se permiten números.')
            opcion = input('Opción: ')
        opcion = int(opcion)
        if opcion == 1:
            if vida_enemigo <= 20:
                golpe_critico = ataque_pesado * 1.5
                vida_enemigo = vida_enemigo - golpe_critico
                print(f'¡Atacaste al enemigo por {golpe_critico} puntos de daño!')
            else:
                vida_enemigo = vida_enemigo - ataque_pesado
                print(f'¡Atacaste al enemigo por {ataque_pesado} puntos de daño!.')
        if opcion == 2:
            for i in range(3):
                print('Has acertado un ataque por 5 de daño.')
                vida_enemigo -= 5
        if opcion == 3:
            if pociones > 0:
                vida_gladiador += 30
                pociones -= 1
                print('Te curaste exitosamente!')
            else:
                print('No quedan pociones.')
        turno_gladiador = False
    else:
        vida_gladiador -= 12
        print('El enemigo te atacó por 12 de daño.')
        turno_gladiador = True

if vida_enemigo <= 0:
    print(f'VICTORIA!!{nombre_gladiador} ha ganado la batalla.')
elif vida_gladiador <= 0:
    print(f'DERROTA. {nombre_gladiador} ha caido en combate.')