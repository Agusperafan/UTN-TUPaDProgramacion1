#1) Caja del kiosco. Objetivo: Simular una compra con validaciones y cálculo de total.
nombre = input('Ingrese su nombre:')
while not nombre.isalpha():
    print('Su nombre solo puede contener letras!')
    nombre = input('Ingrese su nombre: ')

cantidad_productos = input('Ingrese la cantidad de productos que desea comprar: ')
while (not cantidad_productos.isdigit()) or (int(cantidad_productos) == 0):
    print('Debe ingresar un número entero positivo!')
    cantidad_productos = input('Ingrese la cantidad de productos que desea comprar: ')

cantidad_productos = int(cantidad_productos)
contador_productos = 0
precio_total = 0
precio_total_descuentos = 0
lista_precios = []
lista_descuentos = []

for i in range(cantidad_productos): 
    precio_producto = input('Ingrese el precio del producto: ')
    while (not precio_producto.isdigit()) or (int(precio_producto) == 0):
        print('Debe ingresar un precio positivo mayor a 0')
        precio_producto = input('Ingrese el precio del producto: ')
    precio_producto = int(precio_producto)
    descuento_producto = input('El producto posee descuento? (S/N): ').lower()
    while descuento_producto != 's' and descuento_producto != 'n':
        print('Debe ingresar solo S o N.')
        descuento_producto = input('El producto posee descuento? (S/N): ').lower()
    precio_total = precio_total + precio_producto
    lista_precios.append(precio_producto)
    if descuento_producto == 's':
        precio_producto = precio_producto * 0.90
    lista_descuentos.append(descuento_producto)
    precio_total_descuentos = precio_total_descuentos + precio_producto
promedio = precio_total_descuentos / cantidad_productos

print(f'Cliente: {nombre}')
print(f'Cantidad de productos: {cantidad_productos}')
for i in range(cantidad_productos):
    print(f'Producto {i+1} - Precio: {lista_precios[contador_productos]} - Tiene descuento? {lista_descuentos[contador_productos]}')
    contador_productos += 1

print(f'Precio total de la compra sin descuentos: ${precio_total}')
print(f'Precio total de la compra con descuentos: ${precio_total_descuentos}')
print(f'Ahorro total: ${precio_total - precio_total_descuentos}')
print(f'Promedio por producto: ${promedio:.2f}')

