nombre_operador = input('Ingrese su nombre: ')
while not nombre_operador.isalpha():
    print('Su nombre solo puede contener letras.')
    nombre_operador = input('Ingrese su nombre: ')
print('1)Reservar Turno     2)Cancelar turno     3)Ver agenda del día     4)Ver resumen general     5)Salir')
opcion = 1
lunes1 = ''
lunes2 = ''
lunes3 = ''
lunes4 = ''
martes1 = ''
martes2 = ''
martes3 = ''

while opcion != 5:
    opcion = input('Ingrese una opción: ')
    while not opcion.isdigit():
        print('Ingrese un número válido.')
        opcion = input('Opción: ')
    opcion = int(opcion)
    if opcion == 1:
        dia = input('Ingrese un día para reservar (1-Lunes o 2-Martes):')
        while not dia.isdigit() or (int(dia) != 1 and int(dia) != 2):
            print('Ingrese un día válido (1 para Lunes o 2 para Martes).')
            dia = input('Ingrese un día para reservar: ')
        dia = int(dia)
        nombre_paciente = input('Ingrese el nombre del paciente: ')
        while not nombre_paciente.isalpha():
            print('Su nombre solo puede contener letras.')
            nombre_paciente = input('Ingrese su nombre: ')
        if dia == 1:
            if not(nombre_paciente == lunes1) and not(nombre_paciente == lunes2) and not(nombre_paciente == lunes3) and not(nombre_paciente == lunes4):
                if lunes1 == '':
                    lunes1 = nombre_paciente
                    print(f'El turno para {nombre_paciente} fue cargado para el primer turno del Lunes con éxito.')
                elif lunes2 == '':
                    lunes2 = nombre_paciente
                    print(f'El turno para {nombre_paciente} fue cargado para el segundo turno del Lunes con éxito.')
                elif lunes3 == '':
                    lunes3 = nombre_paciente
                    print(f'El turno para {nombre_paciente} fue cargado para el tercer turno del Lunes con éxito.')
                elif lunes4 == '':
                    lunes4 = nombre_paciente
                    print(f'El turno para {nombre_paciente} fue cargado para el cuarto turno del Lunes con éxito.')
                else:
                    print('No quedan turnos libres para el lunes.')
            else:
                print('El paciente ya tiene un turno el día Lunes.')
        else:
            if not(nombre_paciente == martes1) and not(nombre_paciente == martes2) and not(nombre_paciente == martes3):
                if martes1 == '':
                    martes1 = nombre_paciente
                    print(f'El turno para {nombre_paciente} fue cargado para el primer turno del Martes con éxito.')
                elif martes2 == '':
                    martes2 = nombre_paciente
                    print(f'El turno para {nombre_paciente} fue cargado para el segundo turno del Martes con éxito.')
                elif martes3 == '':
                    martes3 = nombre_paciente
                    print(f'El turno para {nombre_paciente} fue cargado para el tercer turno del Martes con éxito.')
                else:
                    print('No quedan turnos libres para el martes.')
            else:
                print('El paciente ya tiene un turno el día Martes.')
    elif opcion == 2:
        dia = input('Ingrese un día para cancelar su turno (1-Lunes o 2-Martes):')
        while not dia.isdigit() or (int(dia) != 1 and int(dia) != 2):
            print('Ingrese un día válido (1 para Lunes o 2 para Martes).')
            dia = input('Ingrese un día para cancelar su turno: ')
        dia = int(dia)
        nombre_paciente = input('Ingrese el nombre del paciente: ')
        while not nombre_paciente.isalpha():
            print('Su nombre solo puede contener letras.')
            nombre_paciente = input('Ingrese su nombre: ')
        if dia == 1:
            if (nombre_paciente == lunes1):
                lunes1 = ''
                print(f'El turno de {nombre_paciente} para el lunes se canceló')
            elif (nombre_paciente == lunes2):
                lunes2 = ''
                print(f'El turno de {nombre_paciente} para el lunes se canceló')
            elif (nombre_paciente == lunes3):
                lunes3 = ''
                print(f'El turno de {nombre_paciente} para el lunes se canceló')
            elif (nombre_paciente == lunes4):
                lunes4 = ''
                print(f'El turno de {nombre_paciente} para el lunes se canceló')
            else:
                print(f'El paciente {nombre_paciente} no tiene un turno el día lunes.')
        else:
            if nombre_paciente == martes1:
                martes1 = ''
                print(f'El turno de {nombre_paciente} para el martes se canceló')
            elif nombre_paciente == martes2:
                martes2 = ''
                print(f'El turno de {nombre_paciente} para el martes se canceló')
            elif nombre_paciente == martes3:
                martes3 = ''
                print(f'El turno de {nombre_paciente} para el martes se canceló')
            else:
                print(f'El paciente {nombre_paciente} no tiene un turno el día martes.')
    elif opcion == 3:
        dia = input('Ingrese un día para mirar su agenda (1-Lunes o 2-Martes):')
        while not dia.isdigit() or (int(dia) != 1 and int(dia) != 2):
            print('Ingrese un día válido (1 para Lunes o 2 para Martes).')
            dia = input('Ingrese un día para mirar su agenda: ')
        dia = int(dia)
        if dia == 1:
            if lunes1 == '':
                print('El turno 1 del lunes está libre.')
            else:
                print(f'El turno 1 del lunes es para {lunes1}')
            if lunes2 == '':
                print('El turno 2 del lunes está libre.')
            else:
                print(f'El turno 2 del lunes es para {lunes2}')
            if lunes3 == '':
                print('El turno 3 del lunes está libre.')
            else:
                print(f'El turno 3 del lunes es para {lunes3}')
            if lunes4 == '':
                print('El turno 4 del lunes está libre.')
            else:
                print(f'El turno 4 del lunes es para {lunes4}')
        else:
            if martes1 == '':
                print('El turno 1 del martes está libre.')
            else:
                print(f'El turno 1 del martes es para {martes1}')
            if martes2 == '':
                print('El turno 2 del martes está libre.')
            else:
                print(f'El turno 2 del martes es para {martes2}')
            if martes3 == '':
                print('El turno 3 del martes está libre.')
            else:
                print(f'El turno 3 del martes es para {martes3}')
    elif opcion == 4:
        contador_lunes = 0
        contador_martes = 0
        print('Turnos del día Lunes:')
        if lunes1 != '':
            contador_lunes += 1
            print(f'El turno 1 del lunes es para {lunes1}')
        else:
            print('El turno 1 del lunes está libre.')
        if lunes2 != '':
            contador_lunes += 1
            print(f'El turno 2 del lunes es para {lunes2}')
        else:
            print('El turno 2 del lunes está libre.')
        if lunes3 != '':
            contador_lunes += 1
            print(f'El turno 3 del lunes es para {lunes3}')
        else:
            print('El turno 3 del lunes está libre.')
        if lunes4 != '':
            contador_lunes += 1
            print(f'El turno 4 del lunes es para {lunes4}')
        else: 
            print('El turno 4 del lunes está libre.')
        print()
        print('Turnos del día Martes:')
        if martes1 != '':
            contador_martes += 1
            print(f'El turno 1 del martes es para {martes1}')
        else:
            print('El turno 1 del martes está libre.')
        if martes2 != '':
            contador_martes += 1
            print(f'El turno 2 del martes es para {martes2}')
        else:
            print('El turno 2 del martes está libre.')
        if martes3 != '':
            contador_martes += 1
            print(f'El turno 3 del martes es para {martes3}')
        else:
            print('El turno 3 del martes está libre.')
        print()
        if contador_lunes == contador_martes:
            print('Ambos días tienen la misma cantidad de turnos ocupados.')
        elif contador_lunes < contador_martes:
            print('El día con mas turnos ocupados es el Martes.')
        else:
            print('El día con mas turnos ocupados es el Lunes.')
    elif opcion == 5:
        print('Hasta luego.')
    else:
        print('Opción fuera de rango.')
