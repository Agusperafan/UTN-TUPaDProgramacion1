usuario_correcto = 'alumno'
clave_correcta = 'python123'
intentos = 1
opcion = 1
usuario = input('Ingrese su usuario: ')
clave = input('Ingrese su clave: ')
while usuario != usuario_correcto or clave != clave_correcta:
    if intentos < 3:
        print(f'''
            Intento {intentos}/3
            Usuario: {usuario}
            Clave: xxx
            Error: Credenciales invalidas
            ''')
        usuario = input('Ingrese su usuario: ')
        clave = input('Ingrese su clave: ')
    elif intentos == 4:
        print(f'''
            Intento 3/3
            Usuario: {usuario}
            Clave: xxx
            Cuenta bloqueada
            ''')
    intentos += 1
if usuario == usuario_correcto and clave == clave_correcta: 
    print(f'''
            Intento {intentos}/3
            Usuario: {usuario}
            Clave: {clave}
            Acceso concedido.
        ''')
    print('1)Estado     2)Cambiar clave     3)Mensaje     4)Salir')
    while opcion != 4:
        opcion = input('Opción: ')
        while not opcion.isdigit():
            print('Ingrese un número válido.')
            opcion = input('Opción: ')
        opcion = int(opcion)
        if opcion == 1:
            print('Usted está inscripto.')
        elif opcion == 2:
            nueva_clave = input('Ingrese su nueva clave: ')
            while len(nueva_clave) < 6:
                print('Error, la clave debe tener al menos caracteres')
                nueva_clave = input('Ingrese su nueva clave: ')
            confirmacion = input('Confirme su nueva clave: ')
            if nueva_clave == confirmacion:
                print('Clave cambiada con éxito.')
            else:
                print('Las claves no coinciden. Fallo al cambiar la clave.')
        elif opcion == 3:
            print('¿Y si sale bien?')
        elif opcion == 4:
            print('Hasta luego.')
        else:
            print('Opción fuera de rango.')
